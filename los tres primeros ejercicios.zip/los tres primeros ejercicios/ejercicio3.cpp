
#include <iostream>
#include <vector>
#include <limits>

using namespace std;

void ingresarMatriz(vector<vector<int>>& matriz, int filas, int columnas) {
    int numero;
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            while (true) {
                cout << "Introduce el valor para la posición (" << i + 1 << ", " << j + 1 << "): ";
                cin >> numero;

                if (cin.fail()) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Entrada inválida. Por favor, ingresa un número entero." << endl;
                } else {
                    matriz[i][j] = numero;
                    break;
                }
            }
        }
    }
}

void mostrarMatriz(const vector<vector<int>>& matriz, int filas, int columnas) {
    cout << "\nLa matriz ingresada es:" << endl;
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int filas = 3, columnas = 3;

    vector<vector<int>> matriz(filas, vector<int>(columnas));

    ingresarMatriz(matriz, filas, columnas);

    mostrarMatriz(matriz, filas, columnas);

    return 0;
}
