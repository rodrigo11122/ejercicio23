
#include <iostream>
#include <vector>
#include <limits>

using namespace std;

int solicitarCantidad() {
    int cantidad;
    while (true) {
        cout << "¿Cuántos elementos deseas ingresar en el arreglo? ";
        cin >> cantidad;
        if (cin.fail() || cantidad <= 0) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Por favor, ingresa un número entero mayor a 0." << endl;
        } else {
            break;
        }
    }
    return cantidad;
}

vector<int> solicitarElementos(int cantidad) {
    vector<int> arreglo;
    int numero;
    for (int i = 0; i < cantidad; i++) {
        while (true) {
            cout << "Ingrese el número " << i + 1 << ": ";
            cin >> numero;
            if (cin.fail()) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Entrada inválida. Por favor, ingresa un número entero." << endl;
            } else {
                arreglo.push_back(numero);
                break;
            }
        }
    }
    return arreglo;
}

void mostrarArreglo(const vector<int>& arreglo) {
    cout << "\nLos elementos ingresados en el arreglo son:" << endl;
    for (int num : arreglo) {
        cout << num << " ";
    }
    cout << endl;
}

int main() {
    int cantidad = solicitarCantidad();
    vector<int> arreglo = solicitarElementos(cantidad);
    mostrarArreglo(arreglo);
    return 0;
}
