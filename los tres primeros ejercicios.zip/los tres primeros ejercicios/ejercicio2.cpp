
#include <iostream>
#include <vector>
#include <limits>

using namespace std;

void solicitarTamañoMatriz(int &m, int &n) {
    while (true) {
        cout << "Introduce el número de filas (m): ";
        cin >> m;
        cout << "Introduce el número de columnas (n): ";
        cin >> n;

        if (cin.fail() || m <= 0 || m > 10 || n <= 0 || n > 10) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Por favor, ingresa valores válidos para las dimensiones (mayores a 0 y menores o iguales a 10)." << endl;
        } else {
            break;
        }
    }
}

void ingresarMatriz(vector<vector<int>> &matriz, int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            while (true) {
                cout << "Introduce el valor para la posición (" << i + 1 << ", " << j + 1 << "): ";
                cin >> matriz[i][j];

                if (cin.fail()) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Entrada inválida. Por favor, ingresa un número entero." << endl;
                } else {
                    break;
                }
            }
        }
    }
}

void mostrarMatriz(const vector<vector<int>> &matriz, int m, int n) {
    cout << "\nLa matriz ingresada es:" << endl;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int m, n;
    solicitarTamañoMatriz(m, n);

    vector<vector<int>> matriz(m, vector<int>(n));

    ingresarMatriz(matriz, m, n);

    mostrarMatriz(matriz, m, n);

    return 0;
}
