
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "funciones.h"

using namespace std;

void mostrarTablero(char tablero[4][4]) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << tablero[i][j] << " ";
        }
        cout << endl;
    }
}

void configurarJugador(char &jugador) {
    cout << "Elige tu símbolo (X o O): ";
    cin >> jugador;
    while (jugador != 'X' && jugador != 'O') {
        cout << "Símbolo inválido. Elige X o O: ";
        cin >> jugador;
    }
}

bool jugar(char tablero[4][4], int posicion, char jugador) {
    int fila = (posicion - 1) / 4;
    int col = (posicion - 1) % 4;

    if (tablero[fila][col] == ' ') {
        tablero[fila][col] = jugador;
        return true;
    } else {
        cout << "La posición ya está ocupada. Elige otra posición." << endl;
        return false;
    }
}

bool verificarGanador(char tablero[4][4], char jugador) {
    for (int i = 0; i < 4; i++) {
        if (tablero[i][0] == jugador && tablero[i][1] == jugador && tablero[i][2] == jugador && tablero[i][3] == jugador) {
            return true;
        }
        if (tablero[0][i] == jugador && tablero[1][i] == jugador && tablero[2][i] == jugador && tablero[3][i] == jugador) {
            return true;
        }
    }

    if (tablero[0][0] == jugador && tablero[1][1] == jugador && tablero[2][2] == jugador && tablero[3][3] == jugador) {
        return true;
    }
    if (tablero[0][3] == jugador && tablero[1][2] == jugador && tablero[2][1] == jugador && tablero[3][0] == jugador) {
        return true;
    }

    return false;
}

bool esEmpate(char tablero[4][4]) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (tablero[i][j] == ' ') {
                return false;
            }
        }
    }
    return true;
}
