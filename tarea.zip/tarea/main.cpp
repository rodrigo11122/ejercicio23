
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "funciones.h"

using namespace std;

int main() {
    char tablero[4][4] = { {' ', ' ', ' ', ' '},
                           {' ', ' ', ' ', ' '},
                           {' ', ' ', ' ', ' '},
                           {' ', ' ', ' ', ' '} };

    char jugador;
    int posicion;
    bool juegoActivo = true;
    bool ganador = false;

    srand(time(0)); // Inicializar la semilla para los números aleatorios

    while (juegoActivo) {
        int opcion;
        cout << "\nMenu: \n";
        cout << "1. Configurar\n";
        cout << "2. Jugar\n";
        cout << "3. Salir\n";
        cout << "Elige una opción: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            configurarJugador(jugador);  // Configurar jugador X o O
            break;

        case 2:
            while (!ganador && !esEmpate(tablero)) {
                mostrarTablero(tablero);
                cout << "Jugador, elige una posición del 1 al 16: ";
                cin >> posicion;

                if (!jugar(tablero, posicion, jugador)) {
                    continue;
                }

                ganador = verificarGanador(tablero, jugador);  // Verificar si el jugador ganó
                if (ganador) {
                    mostrarTablero(tablero);
                    cout << "¡Ganaste!" << endl;
                    break;
                }

                // Movimiento de la computadora (elige una posición aleatoria)
                int posicionComputadora;
                do {
                    posicionComputadora = rand() % 16 + 1;  // Número aleatorio entre 1 y 16
                } while (!jugar(tablero, posicionComputadora, (jugador == 'X' ? 'O' : 'X'))); // Verificar si está libre

                ganador = verificarGanador(tablero, (jugador == 'X' ? 'O' : 'X'));  // Verificar si la computadora ganó
                if (ganador) {
                    mostrarTablero(tablero);
                    cout << "La computadora ganó." << endl;
                    break;
                }
            }

            if (!ganador && esEmpate(tablero)) {
                mostrarTablero(tablero);
                cout << "¡Empate!" << endl;
            }

            break;

        case 3:
            cout << "¡Hasta luego!" << endl;
            juegoActivo = false;
            break;

        default:
            cout << "Opción no válida. Intente nuevamente." << endl;
            break;
        }
    }

    return 0;
}
