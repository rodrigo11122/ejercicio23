
#ifndef FUNCIONES_H
#define FUNCIONES_H

void mostrarTablero(char tablero[4][4]);
void configurarJugador(char &jugador);
bool jugar(char tablero[4][4], int posicion, char jugador);
bool verificarGanador(char tablero[4][4], char jugador);
bool esEmpate(char tablero[4][4]);

#endif
